# WebtoonImageSlicer
A simple tool that takes in an image from command line, scales it to 800 px wide, and exports it to a folder of jpgs, each of which is, at most, 1280 px tall.

## How to Run (Windows)
1. download WebtoonImageSlicer.zip
2. unzip the directory
3. inside the directory, double click Run.bat